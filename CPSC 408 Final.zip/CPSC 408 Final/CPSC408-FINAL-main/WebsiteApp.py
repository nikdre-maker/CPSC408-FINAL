from flask import Flask, render_template, request, redirect, url_for, session
import importmysql as sql

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # For session management

# Helper function for database operations
def execute_query(query, params=None, fetchone=False, fetchall=False):
    cur_obj, conn = sql.establish_connection()
    try:
        cur_obj.execute(query, params or ())
        if fetchone:
            return cur_obj.fetchone()
        if fetchall:
            return cur_obj.fetchall()
        conn.commit()
    finally:
        sql.close_connection(cur_obj, conn)

# Home page
@app.route('/')
def home():
    query = '''
    SELECT Product.ProductID, Product.Name, Product.Price, ProductCategory.Name AS CategoryName
    FROM Product
    JOIN ProductCategory ON Product.CategoryID = ProductCategory.CategoryID
    '''
    products = execute_query(query, fetchall=True)
    
    # Organize products by category
    categorized_products = {}
    for product in products:
        category_name = product['CategoryName']
        if category_name not in categorized_products:
            categorized_products[category_name] = []
        categorized_products[category_name].append(product)
    
    return render_template('Home.html', products=categorized_products)

# Product detail page
@app.route('/product/<int:product_id>')
def product_detail(product_id):
    query_product = '''
    SELECT Product.Name, Product.Description, Product.Price, Product.Size
    FROM Product WHERE ProductID = %s
    '''
    query_inventory = '''
    SELECT Store.Name, Store.Location, StoreInventory.StockQuantity
    FROM StoreInventory
    JOIN Store ON StoreInventory.StoreID = Store.StoreID
    WHERE StoreInventory.ProductID = %s
    '''
    product = execute_query(query_product, (product_id,), fetchone=True)
    inventory = execute_query(query_inventory, (product_id,), fetchall=True)
    
    return render_template('ProductDetail.html', product=product, inventory=inventory)

# Add to cart
@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    product_id = request.form.get('product_id')
    quantity = int(request.form.get('quantity', 1))

    if 'cart' not in session:
        session['cart'] = {}

    if product_id in session['cart']:
        session['cart'][product_id] += quantity
    else:
        session['cart'][product_id] = quantity

    return redirect(url_for('my_cart'))

# My Cart
@app.route('/my_cart')
def my_cart():
    if 'cart' not in session or not session['cart']:
        return render_template('MyCart.html', cart=[], total=0)

    cart = []
    total = 0
    for product_id, quantity in session['cart'].items():
        query = 'SELECT Name, Price FROM Product WHERE ProductID = %s'
        product = execute_query(query, (product_id,), fetchone=True)
        cart.append({'Name': product['Name'], 'Price': product['Price'], 'Quantity': quantity})
        total += product['Price'] * quantity

    return render_template('MyCart.html', cart=cart, total=total)

# Checkout
@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if request.method == 'POST':
        # Process checkout
        session.pop('cart', None)  # Clear the cart after checkout
        return redirect(url_for('home'))

    return render_template('Checkout.html')

if __name__ == '__main__':
    app.run(debug=True)









