-- Active: 1733873316604@@127.0.0.1@3305


CREATE TABLE Customer (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Name VARCHAR(50) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    Email VARCHAR(50) NOT NULL UNIQUE,
    Phone VARCHAR(15) NOT NULL,
    SignupDate DATE,
    CardOnFile INT
);

SELECT * FROM Customer;

CREATE TABLE Payment (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    PaymentMethod VARCHAR(20) NOT NULL,
    OrderID INT NOT NULL,
    PaymentDate DATE,
    CreditCardNumber VARCHAR(4),
    FOREIGN KEY (OrderID) REFERENCES Orders (OrderID)
);

SELECT * FROM Payment; 

CREATE TABLE Orders (
    OrderID INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    OrderDate DATE NOT NULL,
    ArrivalDate DATE,
    ProductID INT NOT NULL,
    CustomerID INT NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);


SELECT * FROM Orders;

CREATE TABLE ProductCategory (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Name VARCHAR(50) NOT NULL
);

SELECT * FROM ProductCategory;

CREATE TABLE Product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Name VARCHAR(50) NOT NULL,
    Description TEXT,
    Price DECIMAL(10,2) NOT NULL,
    Stock INT NOT NULL,
    CategoryID INT NOT NULL,
    ImageURL VARCHAR(100),
    FOREIGN KEY (CategoryID) REFERENCES ProductCategory(CategoryID)
);




CREATE TABLE StoreInventory (
    InventoryID INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    StoreID INT NOT NULL,
    ProductID INT NOT NULL,
    StockQuantity INT NOT NULL,
    Size VARCHAR(10) NOT NULL,
    FOREIGN KEY (StoreID) REFERENCES Store(StoreID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

SELECT * FROM StoreInventory;


CREATE TABLE Store (
    StoreID INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Location VARCHAR(255) NOT NULL,
    Name VARCHAR(50) NOT NULL
);

