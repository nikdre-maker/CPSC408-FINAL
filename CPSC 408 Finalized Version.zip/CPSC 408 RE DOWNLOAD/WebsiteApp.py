from flask import Flask, render_template, request, redirect, url_for, jsonify
import importmysql as sql

app = Flask(__name__)

#displays product page dynamically
@app.route('/product/<int:product_id>')
def product_page(product_id):
    cur_obj, conn = sql.establish_connection()
    
    #sql query that fetches all relevant details 
    query = """
    SELECT 
    p.Name AS ProductName, 
    p.Description, 
    p.Price, 
    p.ImageURL,  
    si.InventoryID,
    si.Size, 
    si.StockQuantity, 
    s.Name AS Location
    FROM Product p
    JOIN StoreInventory si ON p.ProductID = si.ProductID
    JOIN Store s ON si.StoreID = s.StoreID
    WHERE p.ProductID = %s
    """

    cur_obj.execute(query, (product_id,))
    product_data = cur_obj.fetchall()

    #error handling if no data found
    if not product_data:
        return "Product not found", 404

    #product_info dictionary used by frontend
    product_info = {
        "name": product_data[0]["ProductName"],
        "description": product_data[0]["Description"],
        "price": product_data[0]["Price"],
        "image_url": product_data[0]["ImageURL"],
        "sizes": list(set(row["Size"] for row in product_data)),  
        "stores": [
            {
                "location": row["Location"],
                "size": row["Size"],
                "stock": row["StockQuantity"],
                "inventory_id": row["InventoryID"],
            }
            for row in product_data
        ]
    }

    conn.close()

    #render product page based of info
    return render_template('product.html', product=product_info)

#helper function to execute queries
def execute_query(query, params=None, fetchone=False, fetchall=False):
    cur_obj, conn = sql.establish_connection()
    try:
        cur_obj.execute(query, params or ())
        if fetchone:
            return cur_obj.fetchone()
        if fetchall:
            return cur_obj.fetchall()
        conn.commit()
        return None
    finally:
        sql.close_connection(cur_obj, conn)

#home page
@app.route('/')
def home():
    return render_template('Home.html')

#mycart page
@app.route('/MyCart')
def my_cart():
    return render_template('MyCart.html')

#checkout page
@app.route('/Checkout')
def checkout_page():
    return render_template('Checkout.html')

#checkout process with added debugging
@app.route('/ProcessCheckout', methods=['POST'])
def process_checkout():
    print("Starting checkout process...")  
    if request.method == 'POST':
        try:
            checkout_data = request.get_json()
            cart_items = checkout_data.get('cartItems', [])
            customer_info = checkout_data.get('customerInfo', {})
            
            print("Cart items:", cart_items)  
            print("Customer info:", customer_info)  

            if not cart_items:
                print("Error: Cart is empty")  
                return jsonify({'error': 'No items in the cart!'}), 400

            print("Establishing database connection...")  
            cur_obj, conn = sql.establish_connection()
            print("Database connection established")  

            #only use 4 digits of credit card
            card_number = str(customer_info.get('cardOnFile', ''))
            if len(card_number) < 4:
                last_four_digits = card_number.zfill(4)
            else:
                last_four_digits = card_number[-4:]

            #if customer email is already used then use the same customer ID for checkout
            print(f"Checking for existing customer with email: {customer_info['email']}")  
            cur_obj.execute(
                "SELECT CustomerID FROM Customer WHERE Email = %s",
                (customer_info['email'],)
            )
            existing_customer = cur_obj.fetchone()
            
            if existing_customer:
                print(f"Found existing customer with ID: {existing_customer['CustomerID']}")  
                customer_id = existing_customer['CustomerID']
            else:
                print("Creating new customer record...")  
                #new customer inserting
                cur_obj.execute(
                    """
                    INSERT INTO Customer (
                        Name, Email, Phone, Address, SignupDate, CardOnFile
                    ) VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (
                        customer_info['name'],
                        customer_info['email'],
                        customer_info['phone'],
                        customer_info['address'],
                        customer_info['signupDate'],
                        last_four_digits
                    )
                )
                conn.commit()
                customer_id = cur_obj.lastrowid
                print(f"Created new customer with ID: {customer_id}")  

            #processing cart items
            for item in cart_items:
                inventory_id = item.get('inventory_id')
                print(f"Processing item with inventory_id: {inventory_id}")  

                if not inventory_id:
                    print(f"Error: Missing inventory_id for item: {item}")  
                    return jsonify({'error': 'Incomplete item details!'}), 400

                #make sure stock is available
                cur_obj.execute(
                    "SELECT StockQuantity, ProductID FROM StoreInventory WHERE InventoryID = %s",
                    (inventory_id,)
                )
                result = cur_obj.fetchone()
                print(f"Stock check result for inventory_id {inventory_id}:", result)  
                
                if not result or result['StockQuantity'] < 1:
                    print(f"Error: Insufficient stock for inventory_id {inventory_id}")  
                    return jsonify({'error': f'Insufficient stock for item with InventoryID {inventory_id}!'}), 400

                #order insertion
                print(f"Adding order for ProductID {result['ProductID']}")  
                cur_obj.execute(
                    """
                    INSERT INTO Orders (
                        OrderDate, 
                        ArrivalDate, 
                        ProductID, 
                        CustomerID
                    ) VALUES (
                        CURDATE(), 
                        DATE_ADD(CURDATE(), INTERVAL 5 DAY), 
                        %s,
                        %s
                    )
                    """,
                    (result['ProductID'], customer_id)
                )
                order_id = cur_obj.lastrowid
                #insertion into payment table
                price = float(item.get('price'))
                cur_obj.execute(
                    """
                    INSERT INTO Payment (
                        Amount,
                        CreditCardNumber,
                        PaymentMethod,
                        OrderID,
                        PaymentDate
                    ) VALUES (
                        %s,
                        %s,
                        'Credit Card',
                        %s,
                        CURDATE()
                    )
                    """,
                    (price, str(last_four_digits), order_id)
                )

                #update stock quantity
                print(f"Updating stock quantity for inventory_id {inventory_id}")  
                cur_obj.execute(
                    "UPDATE StoreInventory SET StockQuantity = StockQuantity - 1 WHERE InventoryID = %s",
                    (inventory_id,)
                )

            conn.commit()
            print("Checkout process completed successfully")  
            return jsonify({'message': 'Checkout successful!'}), 200

        except Exception as e:
            print(f"Detailed error during checkout: {str(e)}")  
            if 'conn' in locals():
                conn.rollback()
            return jsonify({'error': f'Failed to process checkout: {str(e)}'}), 500

        finally:
            if 'cur_obj' in locals() and 'conn' in locals():
                print("Closing database connection")  
                sql.close_connection(cur_obj, conn)
            
if __name__ == '__main__':
    app.run(debug=True)













